document.addEventListener("DOMContentLoaded", () => {
  const loading = document.getElementById("loading");
  setTimeout(() => loading.style.display = "none", 1500);

  const izinForm = document.getElementById("izinForm");
  izinForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const nama = document.getElementById("nama").value;
    const absen = document.getElementById("absen").value;
    const alasan = document.getElementById("alasan").value;

    let izinList = JSON.parse(localStorage.getItem("izinList")) || [];
    izinList.push({ nama, absen, alasan, waktu: new Date().toLocaleString() });
    localStorage.setItem("izinList", JSON.stringify(izinList));

    alert("Izin berhasil dikirim!");
    izinForm.reset();
  });
});

function loginAdmin() {
  const code = document.getElementById("adminCode").value;
  const message = document.getElementById("loginMessage");
  if (code === "sevenfiveclass") {
    document.getElementById("admin-section").style.display = "block";
    loadHistory();
    message.textContent = "Login berhasil!";
  } else {
    message.textContent = "Kode salah!";
  }
}

function loadHistory() {
  const izinList = JSON.parse(localStorage.getItem("izinList")) || [];
  const historyList = document.getElementById("historyList");
  historyList.innerHTML = "";
  izinList.forEach((izin, index) => {
    const li = document.createElement("li");
    li.textContent = `${izin.waktu} - ${izin.nama} (Absen ${izin.absen}): ${izin.alasan}`;
    historyList.appendChild(li);
  });
}

function refreshHistory() {
  loadHistory();
}
